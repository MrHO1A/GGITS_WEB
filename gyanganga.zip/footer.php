<!--Footer Start-->
<footer class="footer">
    <div class="container">
        <span class="text-muted">Gyan Ganga Institute of Technology and Science &copy;2018</span>
    </div>
</footer>
<!--Footer End-->
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
