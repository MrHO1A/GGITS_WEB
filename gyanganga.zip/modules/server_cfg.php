<?php
define("server_addr","192.168.1.3/gyanganga");