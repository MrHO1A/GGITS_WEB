<?php
define("server_addr","http://192.168.1.3/gyanganga/");