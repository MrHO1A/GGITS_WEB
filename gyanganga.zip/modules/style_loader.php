<?php
include_once "server_cfg.php";
//This file contains all css and javascript files with absolute url
?>

<link rel="stylesheet" href="<?php echo server_addr; ?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo server_addr; ?>css/animate.css">
<link rel="stylesheet" href="<?php echo server_addr; ?>css/jquery-ui.min.css">
<!-- ekko-lightbox -->
<link rel="stylesheet" href="<?php echo server_addr; ?>css/ekko-lightbox.css">
<!-- Custom Css Classes -->
<link rel="stylesheet" href="<?php echo server_addr; ?>css/custom.css">
<!-- Custom Css Classes End -->
