<?php //include "header.php"; ?>
<?php //include "preloader.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- BootStrap Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#212529" />
    <link rel="icon" href="favicon.png">
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <title>Gyan Ganga</title>
    <!-- Fonts Start-->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
    <!--Fonts End-->

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <script src="js/fontawesome-all.min.js"></script>
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/particles.js"></script>
    <!-- Custom Css Classes -->
    <style>
        /* Header Parallax Element Style*/
        .paral {
            min-height: 600px;
            background-attachment: fixed;
            background-size: cover;
            background-position: 50% 50%;
        }
        /*Paragraph For Parallx Section */
        .paral p {
            font-size: 24px;
            color:#f5f5f5;
            text-align: center;
            line-height: 60px;
        }


        /*For Full Width Header*/
        .wide {
            background-image:url('image/image_head.jpeg');
            height: 100vh;
            min-height: 100%;
            max-height: 100%;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;

        }
        .jumbotron {
            margin-bottom: 0px !important;
        }
        /*For Vertical Center Elements In Bootstrap*/
        .vertical-center {
            position: absolute;
            top: 50%;
            left:50%;
            width: 100%;
            transform: translate(-50%,-50%);
        }
        .wide h1{
            font-family: 'Roboto Slab',shrif;
            color: white;
        }
        /*Font Size Increase*/
        .f-20{
            font-size: 30px;
        }

        /*FAB Bottom Header Icon*/
        .icon-to-bottom {
            position:absolute;
            bottom: 1%;
            width: 100%;
        }

        /*Decrease Font Size On Phones*/
        @media all and (min-width: 200px) {
            .wide h1{
                font-size: 45px;
            }
        }
        /*Some Css Classes For Margins*/
        .mar-bottom{
            margin-bottom: .96rem !important;
        }
        .mar-remove{
            margin: 0px !important;
        }
        :root{
            --text-meg:#2f2424;
        }
        .text-meg{
            color: var(--text-meg);
        }
        /*Special Date And Time Card Containers Css*/
        .card .time-card{
            font-weight: bold;
        }
        #particles-js{
            width: 100% !important;
            height: 100% !important;
            background-position: 50% 50%;
        }
        /*Special Date And Time Card Containers Css*/


        /*Partcle Js Container Css*/
        #particles-js canvas{
            position: absolute;
            width: 100%;
            height: 100%;
        }

        /*Card Body Badge Css*/
        .card-body .badge{
            font-size: 18px;
            margin-bottom: 10px;
        }
        .navbar{
            z-index: 5 !important;
        }


        /*Custom Colors*/
        /*Custom Color Button Maroon*/
        .maroon{
            background-color: #b1040e;
            color: white;
            outline:0px;
            transition: all ease-in-out 0.26s;
        }
        .maroon:focus{
            background-color: #b11200;
            color: white;
        }
        .maroon:hover{
            background-color: #b10012;
            color: white;
        }
        /*Custom Color For Button End*/

        .maroon a{
            color:#eeeeee;
        }
        .nav-link{
            color: white !important;
        }
        .dropdown-menu .dropdown-item{
            color: var(--gray-dark);
        }

        /*Border Radius Remove*/
        .border-r-remove{
            border-radius: 0px !important;
        }
    </style>

    <!-- Custom Css Classes End -->

    <!--Script For Smooth Scroll-->
    <script>
        function scroll_to(elementn) {
            $('html, body').animate({
                scrollTop: $(elementn).offset().top
            }, 1000);
        }
    </script>

    <!--    Particle Js-->
    <script>
        particlesJS.load('particles-js','json_cfg/particlesjs-config.json',function () {
            console.log("Started");
        });
    </script>
    <!--    Particle Js End-->

    <?php include "preloader.php"; ?>
</head>

<div class="load"></div>
<!--Navbar Placement Start-->
<nav class="navbar navbar-expand-md maroon">
    <!-- Brand -->

    <a class="navbar-brand" href="#"><span><img src="image/brand_img.gif" width="30" height="30" alt=""></span> GGITS</a>

    <!-- Toggler/collapsibe Button -->
    <button class="navbar-toggler text-white" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <i class="fa fa-bars text-white" aria-hidden="true"></i> Menu
    </button>

    <!-- Navbar links -->
    <div class="collapse navbar-collapse w-100 " id="collapsibleNavbar">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    About Us!
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="showpage.php?mainid=2&subid=113&menu=submain">Vision</a>
                    <a class="dropdown-item" href="showpage.php?mainid=2&subid=146&menu=submain">Mission</a>
                    <a class="dropdown-item" href="showpage.php?mainid=2&subid=179&menu=submain">Management Board</a>
                    <a href="showpage.php?mainid=2&subid=180&menu=submain" class="dropdown-item">Quality Policy</a>
                    <a href="showpage.php?mainid=2&subid=204&menu=submain" class="dropdown-item">National Ranking</a>
                    <a href="showpage.php?mainid=2&subid=231&menu=submain" class="dropdown-item">PEO</a>
                    <a href="showpage.php?mainid=2&subid=232&menu=submain" class="dropdown-item">Annual Budget</a>
                    <a href="showpage.php?mainid=2&subid=233&menu=submain" class="dropdown-item">Mandatory Disclosure</a>
                </div>
            </li>
            </li>
            <li class="nav-item"><a class="nav-link" href="#">Contact Us</a></li>
        </ul>
    </div>
</nav>
<!--Navbar Placement End-->

<!--Full Width Header Start-->
<div class="jumbotron jumbotron-fluid paral wide">
    <div id="particles-js"></div>
    <div class="container vertical-center" >
        <p class="text-center"><img src="image/logo.png"
                                    class="img-fluid"
                                    alt="LOGO" width="150" height="150"></p>
        <h1 class="display-4 text-center animated fadeInDown maroon" style="padding-right: 10px;padding-left: 10px;" >Gyan Ganga Institute of Technology and Science</h1>
    </div>
    <div class="icon-to-bottom">
        <p class="text-center"><a href="#" role="button" class="btn btn-lg maroon" onclick="scroll_to('#content')">Explore <i class="fa fa-arrow-down" aria-hidden="true"></i></a></p>
    </div>
</div>
<!--Full Width Header End-->

<!--Content Section Start-->
<div class="container-fluid" id="content" style="background-color: #f9f6ef;">
    <h1 class="text-center display-4">Gyan Ganga Today</h1>
    <p class="lead text-center">
        The Latest News From Gyan Ganga
    </p>
    <hr class="my-4" />
    <!--News Card Container Start-->
    <div class="container">
        <div class="row justify-content-center">
            <div class="card-columns">
                <div class="card">
                    <img class="card-img-top" src="image/600x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">News 1</h4>
                        <p class="card-text">Some example text.</p>
                        <a href="#" class="btn btn-primary">View News</a>
                    </div>
                </div>
                <div class="card">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">News 2</h4>
                        <p class="card-text">Some example text.</p>
                        <a href="#" class="btn btn-primary">View News</a>
                    </div>
                </div>
                <div class="card">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">News 3</h4>
                        <p class="card-text">Some example text.</p>
                        <a href="#" class="btn btn-primary">View News</a>
                    </div>
                </div>
                <div class="card">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">News 4</h4>
                        <p class="card-text">Some example text.</p>
                        <a href="#" class="btn btn-primary">View News</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--News Card Container End-->
    <p class="text-center mar-remove"><button type="button" class="btn btn-lg maroon mar-bottom border-r-remove" style="padding-left: 60px;padding-right: 60px;">View More News!
        </button></p>
</div>
<!--Content Section End-->

<!--Events Section Start-->
<div class="container-fluid" style="background-color: #2f2424">
    <h1 class="text-center display-4 text-white">Gyan Ganga Events</h1>
    <p class="lead text-white text-center">
        What's happning on campus
    </p>
    <hr class="my-2 border-white mar-bottom" />
    <div class="container">
        <div class="row justify-content-center">
            <!--            Single Card Sinp-->
            <div class="col-md-5">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body" style="overflow: auto">
                        <!--Date Container-->
                        <span class="badge badge-dark">25 JUNE</span>
                        <!--Date Container End-->
                        <a><h4 class="card-title text-meg">Celeberation</h4></a>
                        <p class="card-text" style="max-height: 70px; overflow: hidden">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras non magna justo. Nulla bibendum quam tempus faucibus lobortis. Mauris massa felis, tincidunt vitae erat eu, condimentum fringilla felis. Maecenas eu aliquet tortor, eget sagittis neque. Donec sit amet cursus augue. Curabitur tristique turpis quis leo sodales ultricies. Suspendisse justo nunc, tincidunt eu tincidunt a, commodo ut orci. Aenean sed aliquet ex. Morbi sit amet suscipit diam. Integer at facilisis enim, id elementum neque. Vivamus quis aliquet nisl.

                        </p>
                        <!--Time-->
                        <p class="text-dark time-card">9:30AM</p>
                        <!--Time End-->
                    </div>

                </div>
            </div>
            <!--            Single Card Snip End-->
            <div class="col-md-5">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body" style="overflow: auto">
                        <!--Date Container-->
                        <span class="badge badge-dark">27 JUNE</span>
                        <!--Date Container End-->
                        <a><h4 class="card-title text-meg">Celeberation</h4></a>
                        <p class="card-text" style="max-height: 70px; overflow: hidden">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras non magna justo. Nulla bibendum quam tempus faucibus lobortis. Mauris massa felis, tincidunt vitae erat eu, condimentum fringilla felis. Maecenas eu aliquet tortor, eget sagittis neque. Donec sit amet cursus augue. Curabitur tristique turpis quis leo sodales ultricies. Suspendisse justo nunc, tincidunt eu tincidunt a, commodo ut orci. Aenean sed aliquet ex. Morbi sit amet suscipit diam. Integer at facilisis enim, id elementum neque. Vivamus quis aliquet nisl.

                        </p>
                        <!--Time-->
                        <p class="text-dark time-card">9:30AM</p>
                        <!--Time End-->
                    </div>

                </div>
            </div><div class="col-md-5">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body" style="overflow: auto">
                        <!--Date Container-->
                        <span class="badge badge-dark">26 JUNE</span>
                        <!--Date Container End-->
                        <a><h4 class="card-title text-meg">Celeberation</h4></a>
                        <p class="card-text" style="max-height: 70px; overflow: hidden">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras non magna justo. Nulla bibendum quam tempus faucibus lobortis. Mauris massa felis, tincidunt vitae erat eu, condimentum fringilla felis. Maecenas eu aliquet tortor, eget sagittis neque. Donec sit amet cursus augue. Curabitur tristique turpis quis leo sodales ultricies. Suspendisse justo nunc, tincidunt eu tincidunt a, commodo ut orci. Aenean sed aliquet ex. Morbi sit amet suscipit diam. Integer at facilisis enim, id elementum neque. Vivamus quis aliquet nisl.

                        </p>
                        <!--Time-->
                        <p class="text-dark time-card">9:30AM</p>
                        <!--Time End-->
                    </div>

                </div>
            </div>

        </div>
    </div>
    <p class="text-center mar-remove"><button type="button" class="btn btn-lg maroon mar-bottom border-r-remove" style="padding-left: 60px;padding-right: 60px;">View More Events!
        </button></p>
</div>

<!--Acadmic Section-->
<div class="jumbotron jumbotron-fluid" style="background-color: #f9f6ef;">
    <div class="container">
        <h1 class="display-3 text-center">Acadmics</h1>
        <p class="lead text-center">Preparing students to make meaningful contributions to society as engaged citizens and leaders in a complex world</p>
        <hr class="my-2">
        <div class="row">
            <!--                One Acadmic Card-->
            <div class="col-md-4 align-items-stretch">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Undergraduate Education</h4>
                        <p class="card-text">Rich learning experiences that provide a broad liberal arts foundation and deep subject-area expertise</p>
                        <a href="#" class="btn-link">Undergraduate Education</a>
                    </div>
                </div>
            </div>
            <!--                One Acadmic Card End-->
            <div class="col-md-4 align-items-stretch">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Graduate Education</h4>
                        <p class="card-text">Unsurpassed opportunities to participate in the advancement of entire fields of knowledge</p>
                        <a href="#" class="btn-link">Graduate Education</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 align-items-stretch">
                <div class="card mar-bottom">
                    <img class="card-img-top" src="image/400x400.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Lifelong learning</h4>
                        <p class="card-text">Continuing adult education, executive and professional programs, and programs for K-12 students</p>
                        <a href="#" class="btn-link">Programs for Lifelong Learning</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <h3 class="display-4 text-center">Seven Branches To Pursue Your Passion</h3>
</div>
<!--Acadmics Section End-->
<footer class="footer">
    <div class="container">
        <span class="text-muted">Gyan Ganga Institute of Technology and Science &copy;2018</span>
    </div>
</footer>
<!--Event Section End-->
<?php include "footer.php"; ?>
